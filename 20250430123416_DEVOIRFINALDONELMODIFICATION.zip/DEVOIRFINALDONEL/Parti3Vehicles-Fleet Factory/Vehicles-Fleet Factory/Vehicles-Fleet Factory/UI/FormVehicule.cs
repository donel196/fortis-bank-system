﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vehicles_Fleet_Factory.BLL;

namespace Vehicles_Fleet_Factory.UI
{
    public partial class FormVehicule : Form
    {
        public FormVehicule()
        {
            InitializeComponent();
        }


        private void Vehicule_Load(object sender, EventArgs e)
        {
            // Parcourt toutes les valeurs de l'énumération EnumTypeVehicule
            foreach (EnumTypeVehicule item in Enum.GetValues(typeof(EnumTypeVehicule)))
            {
                // Ajoute chaque valeur à la comboBox et convertit en chaîne
                this.comboBoxTypeVehicule.Items.Add(item.ToString());
            }

            // Définit la valeur sélectionnée par défaut à "Undefined"
            this.comboBoxTypeVehicule.SelectedItem = EnumTypeVehicule.Undefined.ToString();
        }

        private void comboBoxTypeVehicule_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Déclaration de la variable pour stocker le type de véhicule sélectionné
            EnumTypeVehicule currentType;

            // Tente de convertir le texte sélectionné dans la comboBox en valeur de l'énumération EnumTypeVehicule
            Enum.TryParse(this.comboBoxTypeVehicule.Text, out currentType);

            // En fonction du type de véhicule, on affiche ou cache les group boxes de support

            if (currentType == EnumTypeVehicule.ElectricVehicule)
            {
                // Si le véhicule est de type Electric, on affiche le support électrique et cache les autres
                groupBoxElectricSupport.Visible = true;
                groupBoxFuelConsumed.Visible = false;
                groupBoxSimulation.Visible = true; 
            }
            else if (currentType == EnumTypeVehicule.GazolineVehicule)
            {
                // Pour un véhicule de type Gasoline, on affiche uniquement le support carburant et on cache les autres
                groupBoxElectricSupport.Visible = false;
                groupBoxFuelConsumed.Visible = true;
                groupBoxSimulation.Visible = true;

            }
            else if (currentType == EnumTypeVehicule.HybridVehicule)
            {
                // Pour un véhicule hybride, on affiche le support hybride et on cache les supports Electric et Fuel
                groupBoxElectricSupport.Visible = true;
                groupBoxFuelConsumed.Visible = true;
                groupBoxSimulation.Visible = true;


            }
            else if (currentType == EnumTypeVehicule.SportVehicule)
            {
                // Pour un véhicule SportVehicule, on affiche le support hybride et on cache les supports Electric et Fuel
                groupBoxElectricSupport.Visible = true;
                groupBoxFuelConsumed.Visible = true;
                groupBoxSimulation.Visible = true;

            }
            else
            {
                // Pour toute autre valeur (par exemple Undefined ou tout type non prévu),
                // on cache l'ensemble des group boxes de support
                groupBoxElectricSupport.Visible = false;
                groupBoxFuelConsumed.Visible = false;
                groupBoxSimulation.Visible = false;


            }
        }


        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        int itemIndex = -1;
        private void listBoxVehicule_SelectedIndexChanged(object sender, EventArgs e)
        {
            itemIndex = listBoxVehicule.SelectedIndex;

            if (itemIndex < 0 || itemIndex >= DataCollection.ListOfVehicules.Count)
                return;

            Vehicule vehicule = DataCollection.ListOfVehicules[itemIndex];

            // Champs communs
            textBoxSerialNumber.Text = vehicule.SerialNumber;
            textBoxMade.Text = vehicule.Made;
            textBoxModel.Text = vehicule.Model;
            textBoxTripCounter.Text = vehicule.TripCounter.ToString("F2");
            comboBoxTypeVehicule.Text = vehicule.TypeVehicule.ToString();

            // Effacer les champs spécifiques d'abord
            textBoxFuelConsumed.Clear();
            textBoxElectricSupport.Clear();

            // Champs spécifiques selon le type de véhicule
            if (vehicule is GazolineVehicule gaz)
            {
                textBoxFuelConsumed.Text = gaz.FuelConsumption.ToString("F2");
            }
            else if (vehicule is ElectricVehicule elec)
            {
                textBoxElectricSupport.Text = elec.ElectricConsumption.ToString("F2");
            }
            else if (vehicule is HybridVehicule hybrid)
            {
                textBoxFuelConsumed.Text = hybrid.FuelConsumption.ToString("F2");
                textBoxElectricSupport.Text = hybrid.ElectricConsumption.ToString("F2");
            }
            else if (vehicule is SportVehicule sport)
            {
                textBoxFuelConsumed.Text = sport.FuelConsumption.ToString("F2");
                textBoxElectricSupport.Text = sport.ElectricConsumption.ToString("F2");
            }

            // Date
            textBoxYear.Text = vehicule.MadeDate.getYear().ToString();
            textBoxMonth.Text = vehicule.MadeDate.getMonth().ToString();
            textBoxDay.Text = vehicule.MadeDate.getDay().ToString();
        }


        private void buttonUPDATE_Click(object sender, EventArgs e)
        {
            // Vérifie si un élément est sélectionné dans la ListBox
            if (itemIndex >= 0)
            {
                Vehicule updatedVehicule = null;
                // Récupère le type de véhicule à partir de la comboBox (converti en valeur d'énumération)
                EnumTypeVehicule currentVehiculeType;
                Enum.TryParse(this.comboBoxTypeVehicule.Text, out currentVehiculeType);

                if (currentVehiculeType == EnumTypeVehicule.ElectricVehicule)
                {
                    // Création d'un véhicule électrique sans modifier tripCounter via l'initialiseur
                    updatedVehicule = new ElectricVehicule
                    {
                        Made = this.textBoxMade.Text,
                        Model = this.textBoxModel.Text,
                        MadeDate = new Date(
                            Convert.ToInt32(this.textBoxYear.Text),
                            Convert.ToInt32(this.textBoxMonth.Text),
                            Convert.ToInt32(this.textBoxDay.Text)
                        ),
                        ElectricConsumption = Convert.ToDouble(this.textBoxElectricSupport.Text)
                    };
                    // Mise à jour du tripCounter à l'aide de la méthode publique (setter Java)
                    updatedVehicule.setTripCounter(Convert.ToDouble(this.textBoxTripCounter.Text));
                }
                else if (currentVehiculeType == EnumTypeVehicule.GazolineVehicule)
                {
                    // Création d'un véhicule à essence
                    updatedVehicule = new GazolineVehicule
                    {
                        Made = this.textBoxMade.Text,
                        Model = this.textBoxModel.Text,
                        MadeDate = new Date(
                            Convert.ToInt32(this.textBoxYear.Text),
                            Convert.ToInt32(this.textBoxMonth.Text),
                            Convert.ToInt32(this.textBoxDay.Text)
                        ),
                        FuelConsumption = Convert.ToDouble(this.textBoxFuelConsumed.Text)
                    };
                    // Mise à jour du tripCounter via la méthode publique
                    updatedVehicule.setTripCounter(Convert.ToDouble(this.textBoxTripCounter.Text));
                }
                else if (currentVehiculeType == EnumTypeVehicule.HybridVehicule)
                {
                    // Création d'un véhicule hybride
                    updatedVehicule = new HybridVehicule
                    {
                        Made = this.textBoxMade.Text,
                        Model = this.textBoxModel.Text,
                        MadeDate = new Date(
                            Convert.ToInt32(this.textBoxYear.Text),
                            Convert.ToInt32(this.textBoxMonth.Text),
                            Convert.ToInt32(this.textBoxDay.Text)
                        ),
                        ElectricConsumption = Convert.ToDouble(this.textBoxElectricSupport.Text),
                        FuelConsumption = Convert.ToDouble(this.textBoxFuelConsumed.Text)
                    };
                    // Mise à jour du tripCounter via le setter public style Java
                    updatedVehicule.setTripCounter(Convert.ToDouble(this.textBoxTripCounter.Text));
                }
                else if (currentVehiculeType == EnumTypeVehicule.SportVehicule)
                {
                    // Création d'un véhicule hybride
                    updatedVehicule = new SportVehicule
                    {
                        Made = this.textBoxMade.Text,
                        Model = this.textBoxModel.Text,
                        MadeDate = new Date(
                            Convert.ToInt32(this.textBoxYear.Text),
                            Convert.ToInt32(this.textBoxMonth.Text),
                            Convert.ToInt32(this.textBoxDay.Text)
                        ),
                        ElectricConsumption = Convert.ToDouble(this.textBoxElectricSupport.Text),
                        FuelConsumption = Convert.ToDouble(this.textBoxFuelConsumed.Text)
                    };
                    // Mise à jour du tripCounter via le setter public style Java
                    updatedVehicule.setTripCounter(Convert.ToDouble(this.textBoxTripCounter.Text));
                }
                updatedVehicule.SerialNumber = DataCollection.ListOfVehicules[itemIndex].SerialNumber;
                updatedVehicule.TypeVehicule = DataCollection.ListOfVehicules[itemIndex].TypeVehicule;

                // Utilise la méthode Update de DataCollection pour remplacer l'élément existant
                if (updatedVehicule != null)
                {
                    DataCollection.Update(itemIndex, updatedVehicule);
                    MessageBox.Show("Vehicle updated successfully.");
                }
                else
                {
                    MessageBox.Show("Please select a valid vehicle type.");
                }
            }
            else
            {
                MessageBox.Show("No Vehicle selected.");
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            // Conversion du texte de la comboBox en valeur d'énumération pour le type de véhicule
            EnumTypeVehicule currentVehiculeType;
            Enum.TryParse(this.comboBoxTypeVehicule.Text, out currentVehiculeType);
            // Vérification des zones de texte pour s'assurer qu'elles ne soient pas vides
            if (string.IsNullOrWhiteSpace(this.textBoxSerialNumber.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxMade.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxModel.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxYear.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxMonth.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxDay.Text) ||
                string.IsNullOrWhiteSpace(this.comboBoxTypeVehicule.Text))
            {
                // Affiche un message si un ou plusieurs champs sont vides
                MessageBox.Show("Veuillez remplir tous les champs obligatoires avant d'ajouter un véhicule.", "Champs incomplets", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string serialNumber = this.textBoxSerialNumber.Text;
            bool serialExists = DataCollection.ListOfVehicules.Any(v => v.SerialNumber == serialNumber);

            if (serialExists)
            {
                // Affiche un message d'erreur si le numéro de série est déjà dans la liste
                MessageBox.Show("Ce numéro de série existe déjà. Veuillez en saisir un autre.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (currentVehiculeType == EnumTypeVehicule.ElectricVehicule)
            {
                // Création d'un véhicule électrique
                ElectricVehicule elecVeh = new ElectricVehicule
                {
                    // Propriétés communes
                    SerialNumber = this.textBoxSerialNumber.Text,
                    Made = this.textBoxMade.Text,
                    Model = this.textBoxModel.Text,
                    MadeDate = new Date(
                        Convert.ToInt32(this.textBoxYear.Text),
                        Convert.ToInt32(this.textBoxMonth.Text),
                        Convert.ToInt32(this.textBoxDay.Text)
                    ),
                    // Propriété spécifique pour le véhicule électrique
                    ElectricConsumption = Convert.ToDouble(this.textBoxElectricSupport.Text),
                    // Affectation du type
                    TypeVehicule = currentVehiculeType
                };

                DataCollection.Add(elecVeh);
                MessageBox.Show("Electric Vehicle inserted successfully.");
            }
            else if (currentVehiculeType == EnumTypeVehicule.GazolineVehicule)
            {
                // Création d'un véhicule à essence
                GazolineVehicule gasVeh = new GazolineVehicule
                {
                    // Propriétés communes
                    SerialNumber = this.textBoxSerialNumber.Text,
                    Made = this.textBoxMade.Text,
                    Model = this.textBoxModel.Text,
                    MadeDate = new Date(
                        Convert.ToInt32(this.textBoxYear.Text),
                        Convert.ToInt32(this.textBoxMonth.Text),
                        Convert.ToInt32(this.textBoxDay.Text)
                    ),
                    // Propriété spécifique pour le véhicule à essence
                    FuelConsumption = Convert.ToDouble(this.textBoxFuelConsumed.Text),
                    // Affectation du type
                    TypeVehicule = currentVehiculeType
                };

                DataCollection.Add(gasVeh);
                MessageBox.Show("Gasoline Vehicle inserted successfully.");
            }
            else if (currentVehiculeType == EnumTypeVehicule.HybridVehicule)
            {
                // Création d'un véhicule hybride
                HybridVehicule hybridVeh = new HybridVehicule
                {
                    // Propriétés communes
                    SerialNumber = this.textBoxSerialNumber.Text,
                    Made = this.textBoxMade.Text,
                    Model = this.textBoxModel.Text,
                    MadeDate = new Date(
                        Convert.ToInt32(this.textBoxYear.Text),
                        Convert.ToInt32(this.textBoxMonth.Text),
                        Convert.ToInt32(this.textBoxDay.Text)
                    ),
                    // Propriétés spécifiques pour un véhicule hybride
                    ElectricConsumption = Convert.ToDouble(this.textBoxElectricSupport.Text),
                    FuelConsumption = Convert.ToDouble(this.textBoxFuelConsumed.Text),
                    // Affectation du type
                    TypeVehicule = currentVehiculeType
                };

                DataCollection.Add(hybridVeh);
                MessageBox.Show("Hybrid Vehicle inserted successfully.");
            } else if (currentVehiculeType == EnumTypeVehicule.SportVehicule)
              {
                // Création d'un véhicule sport
                SportVehicule SportVeh = new SportVehicule
                {
                    // Propriétés communes
                    SerialNumber = this.textBoxSerialNumber.Text,
                    Made = this.textBoxMade.Text,
                    Model = this.textBoxModel.Text,
                    MadeDate = new Date(
                        Convert.ToInt32(this.textBoxYear.Text),
                        Convert.ToInt32(this.textBoxMonth.Text),
                        Convert.ToInt32(this.textBoxDay.Text)
                    ),
                    // Propriétés spécifiques pour un véhicule hybride
                    ElectricConsumption = Convert.ToDouble(this.textBoxElectricSupport.Text),
                    FuelConsumption = Convert.ToDouble(this.textBoxFuelConsumed.Text),
                    // Affectation du type
                    TypeVehicule = currentVehiculeType
                };

                DataCollection.Add(SportVeh);
                MessageBox.Show("Sport Vehicle inserted successfully.");
            }
            else
            {
                MessageBox.Show("Please select a valid vehicle type.");
            }
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            // Efface la ListBox du formulaire
            this.listBoxVehicule.Items.Clear();

            // Vérifie que la liste en mémoire n'est pas vide
            if (DataCollection.ListOfVehicules.Count > 0)
            {
                // Parcourt la liste des véhicules avec une boucle for
                for (int i = 0; i < DataCollection.ListOfVehicules.Count; i++)
                {
                    // Récupère le véhicule courant de la collection
                    Vehicule currentVehicule = DataCollection.ListOfVehicules[i];
                    // Ajoute la représentation textuelle du véhicule dans la ListBox
                    this.listBoxVehicule.Items.Add(currentVehicule.ToString());
                }
            }
            else
            {
                // Affiche un message si la liste des véhicules est vide
                MessageBox.Show("La liste des véhicules en mémoire est VIDE");
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            // Vérifie si un véhicule est sélectionné dans la ListBox en vérifiant l'indice
            if (itemIndex >= 0 && itemIndex < DataCollection.ListOfVehicules.Count)
            {
                // Supprime le véhicule de la collection à l'indice spécifié
                DataCollection.RemoveAt(itemIndex);
                // Affiche un message de confirmation pour l'utilisateur
                MessageBox.Show("Véhicule supprimé.");
            }
            else
            {
                // Affiche un message d'erreur si aucun véhicule n'est sélectionné
                MessageBox.Show("Aucun véhicule sélectionné.");
            }

        }

        private void buttoSearch_Click(object sender, EventArgs e)
        {
            // Récupère le numéro de série à rechercher depuis le TextBox dédié
            string searchSerial = this.textBoxSerialNumber.Text;

            // Recherche le véhicule dans la collection à partir du numéro de série
            Vehicule searchedVehicule = DataCollection.Search(searchSerial);

            // Vérifie si un véhicule a été trouvé
            if (searchedVehicule == null)
            {
                MessageBox.Show("Aucun véhicule trouvé avec le numéro de série spécifié.");
            }
            else
            {
                MessageBox.Show("Véhicule trouvé : " + searchedVehicule.ToString());

                // Efface la ListBox et affiche uniquement le véhicule trouvé
                this.listBoxVehicule.Items.Clear();
                this.listBoxVehicule.Items.Add(searchedVehicule.ToString());
            }

        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            //Efface tous les éléments de la ListBox des véhicules
            this.listBoxVehicule.Items.Clear();

            // Efface le contenu des zones de texte concernées par la saisie des informations du véhicule
            this.textBoxSerialNumber.Clear();      // Efface le numéro de série
            this.textBoxMade.Clear();              // Efface le fabricant
            this.textBoxModel.Clear();             // Efface le modèle
            this.textBoxYear.Clear();              // Efface l'année
            this.textBoxMonth.Clear();             // Efface le mois
            this.textBoxDay.Clear();               // Efface le jour
            this.comboBoxTypeVehicule.SelectedItem = EnumTypeVehicule.Undefined;
            // Efface les zones de texte spécifiques aux consommations
            this.textBoxElectricSupport.Clear();   // Efface la consommation électrique
            this.textBoxFuelConsumed.Clear();       // Efface la consommation de carburant
            this.textBoxElectricSupport.Clear(); // Optionnel pour le véhicule hybride
            this.textBoxTripCounter.Clear();

            // Optionnel : réinitialiser la comboBox (le type de véhicule) à une valeur par défaut, par exemple "ElectricVehicule"
            this.comboBoxTypeVehicule.SelectedIndex = -1;

            // Affiche un message de confirmation à l'utilisateur
            MessageBox.Show("Tous les champs ont été effacés.");
        }

       
        private void buttonSortEfficiency_Click(object sender, EventArgs e)
        {
            // Vérifie que la liste des véhicules n'est pas vide
            if (DataCollection.ListOfVehicules.Count > 0)
            {
                // Tri par sélection : on parcourt la liste et on échange l'élément actuel 
                // avec l'élément qui possède l'efficacité énergétique la plus faible
                for (int i = 0; i < DataCollection.ListOfVehicules.Count - 1; i++)
                {
                    // On suppose que l'indice i contient déjà l'élément de l'efficacité minimale
                    int indexMin = i;
                    // On regarde ensuite les éléments restants pour trouver éventuellement un plus petit rendement
                    for (int j = i + 1; j < DataCollection.ListOfVehicules.Count; j++)
                    {
                        // Si l'efficacité énergétique de l'élément j est inférieure à celle de l'indice indexMin
                        if (DataCollection.ListOfVehicules[j].CalculateMileageEfficiency() < DataCollection.ListOfVehicules[indexMin].CalculateMileageEfficiency())
                        {
                            // On met à jour l'indice du minimum trouvé
                            indexMin = j;
                        }
                    }
                    // Si un indice plus petit a été trouvé, on échange les éléments à l'indice i et indexMin
                    if (indexMin != i)
                    {
                        Vehicule temp = DataCollection.ListOfVehicules[i];
                        DataCollection.ListOfVehicules[i] = DataCollection.ListOfVehicules[indexMin];
                        DataCollection.ListOfVehicules[indexMin] = temp;
                    }
                }

                // Après le tri, on efface la ListBox pour afficher la liste triée
                this.listBoxVehicule.Items.Clear();

                // Parcourt la liste triée et ajoute chaque véhicule à la ListBox
                for (int i = 0; i < DataCollection.ListOfVehicules.Count; i++)
                {
                    Vehicule currentVehicule = DataCollection.ListOfVehicules[i];
                    // Concatène la représentation du véhicule et son efficacité énergétique formatée sur deux décimales
                    this.listBoxVehicule.Items.Add(
                        currentVehicule.ToString() + currentVehicule.CalculateMileageEfficiency().ToString()
                    );
                }
            }
            else
            {
                // Affiche un message si la liste est vide
                MessageBox.Show("La liste des véhicules est vide.");
            }
        }

       

        private void buttonMakeTrip_Click(object sender, EventArgs e)
        {
            // 1. Vérifier qu'un véhicule est sélectionné dans la ListBox.
            int index = listBoxVehicule.SelectedIndex;
            if (index < 0 || index >= DataCollection.ListOfVehicules.Count)
            {
                MessageBox.Show("Veuillez sélectionner un véhicule dans la liste.");
                return;
            }

            // 2. Récupérer le véhicule sélectionné depuis la collection.
            Vehicule vehiculeSelectionne = DataCollection.ListOfVehicules[index];

            // 3. Récupérer et valider la distance saisie dans le TextBox dédié au trajet.
            double distance;
            if (!double.TryParse(this.textBoxTripCounter.Text, out distance) || distance <= 0)
            {
                MessageBox.Show("Veuillez entrer une distance valide (supérieure à 0).");
                return;
            }

            if (this.textBoxTripCounter.Text!="") { 
            // 4. Appeler la méthode MakeTrip sur le véhicule sélectionné.
            // Cette méthode met à jour le trip counter et effectue, selon le type de véhicule,
            // le calcul et l'enregistrement de la consommation (électrique, carburant ou les deux).
            vehiculeSelectionne.MakeTrip(distance);

            // 5. Mettre à jour l'affichage du trip counter dans le TextBox dédié.
            this.textBoxTripCounter.Text = vehiculeSelectionne.TripCounter.ToString();

            // 6. Rafraîchir l'affichage dans la ListBox pour que les nouvelles valeurs soient affichées.
            // Ici, nous mettons à jour uniquement l'élément modifié.
            this.listBoxVehicule.Items[index] = vehiculeSelectionne.ToString() + " - Efficacy : " +
                                                   vehiculeSelectionne.CalculateMileageEfficiency().ToString();

            // 7. Afficher un message récapitulatif détaillant le trajet enregistré.
            string message = "Le trajet de " + distance + " km a été enregistré pour le véhicule.\n";
            message += "Distance totale parcourue : " + vehiculeSelectionne.TripCounter.ToString() + " km.\n";
            message += "Efficacité énergétique : " + vehiculeSelectionne.CalculateMileageEfficiency().ToString();

            MessageBox.Show(message, "Informations du trajet");
            }
            else
            {
                vehiculeSelectionne.MakeTrip();
                this.listBoxVehicule.Items[index] = vehiculeSelectionne.ToString() + " - Efficacy : " +
                                                vehiculeSelectionne.CalculateMileageEfficiency().ToString();

                // 7. Afficher un message récapitulatif détaillant le trajet enregistré.
                string message = "Le trajet de " + distance + " km a été enregistré pour le véhicule.\n";
                message += "Distance totale parcourue : " + vehiculeSelectionne.TripCounter.ToString() + " km.\n";
                message += "Efficacité énergétique : " + vehiculeSelectionne.CalculateMileageEfficiency().ToString();

                MessageBox.Show(message, "Informations du trajet");
            } 

        }
      
        
        private void buttonReset_Click(object sender, EventArgs e)
        {
            // Efface tous les éléments de la ListBox des véhicules
            this.listBoxVehicule.Items.Clear();
            this.comboBoxTypeVehicule.SelectedItem = EnumTypeVehicule.Undefined;

            // Réinitialise les TextBox dédiés aux informations du véhicule
            this.textBoxSerialNumber.Clear();      // Efface le numéro de série
            this.textBoxMade.Clear();              // Efface le fabricant
            this.textBoxModel.Clear();             // Efface le modèle
            this.textBoxYear.Clear();              // Efface l'année
            this.textBoxMonth.Clear();             // Efface le mois
            this.textBoxDay.Clear();               // Efface le jour

            // Efface les TextBox pour les consommations spécifiques
            this.textBoxElectricSupport.Clear();   // Efface la consommation électrique
            this.textBoxFuelConsumed.Clear();       // Efface la consommation de carburant
          
            
            // Réinitialise le TextBox pour le trip counter (distance totale parcourue)
            this.textBoxTripCounter.Clear();

            // Réinitialise la ComboBox du type de véhicule (aucune sélection)
            this.comboBoxTypeVehicule.SelectedIndex = -1;
            DataCollection.listOfVehicules.Clear();

            // Affiche un message de confirmation à l'utilisateur
            MessageBox.Show("Tous les champs et la liste ont été réinitialisés.");
        }

        private void buttonWriteXml_Click(object sender, EventArgs e)
        {
            // Appelle la fonction qui écrit la liste des véhicules dans le fichier XML
            VehiculeFileManager.WriteToXmlFile(DataCollection.ListOfVehicules);
            MessageBox.Show("La liste des véhicules a été enregistrée dans le fichier XML !");
        }

        private void buttonReadXml_Click(object sender, EventArgs e)
        {
            // 1. Lire les véhicules depuis le fichier XML
            DataCollection.ListOfVehicules = VehiculeFileManager.ReadFromXmlFile();

            // 2. Vider la ListBox
            listBoxVehicule.Items.Clear();

            // 3. Remplir la ListBox avec les objets chargés
            foreach (Vehicule veh in DataCollection.ListOfVehicules)
            {
                listBoxVehicule.Items.Add(veh.ToString()); // ToString() doit être bien défini dans chaque classe
            }

            // 4. Message de confirmation
            MessageBox.Show("Les véhicules ont été chargés et affichés depuis le fichier XML !");
        }


        private void buttonWriteText_Click(object sender, EventArgs e)
        {
            // Appelle la fonction qui écrit la liste des véhicules dans le fichier texte
            VehiculeFileManager.WriteToTextFile(DataCollection.ListOfVehicules);
            MessageBox.Show("La liste des véhicules a été enregistrée dans le fichier texte !");
        }

        private void buttonReadText_Click(object sender, EventArgs e)
        {
            // Récupère les lignes du fichier texte (chaînes simples)
            List<string> vehiculesFromText = VehiculeFileManager.ReadFromTextFile();

            // Vide la ListBox avant l'affichage
            listBoxVehicule.Items.Clear();

            // Ajoute chaque ligne à la ListBox
            foreach (string line in vehiculesFromText)
            {
                listBoxVehicule.Items.Add(line);
            }


            MessageBox.Show("Les lignes ont été chargées depuis le fichier texte !");
        }



        private void buttonExit_Click(object sender, EventArgs e)
        {
            // Afficher une boîte de confirmation avant la déconnexion
            DialogResult confirmation = MessageBox.Show(
                "Êtes-vous sûr de vouloir vous déconnecter ?",
                "Confirmation de déconnexion",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            // Si l'utilisateur confirme, effectuer la déconnexion
            if (confirmation == DialogResult.Yes)
            {
                // Fermer le tableau de bord actuel et revenir à la fenêtre de connexion
                this.Hide(); // Cache la fenêtre actuelle (par exemple, tableau de bord)
                LoginForm loginForm = new LoginForm(); // Exemple de formulaire de connexion
                loginForm.Show();
            }
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void textBoxFuelConsumed_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxTripCounter_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void groupBoxFuelConsumed_Enter(object sender, EventArgs e)
        {

        }
    }


}





