﻿namespace Vehicles_Fleet_Factory.UI
{
    partial class FormVehicule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxModel = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.buttonWriteXml = new System.Windows.Forms.Button();
            this.buttonReadXml = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonWriteText = new System.Windows.Forms.Button();
            this.buttonReadText = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonReset = new System.Windows.Forms.Button();
            this.groupBoxEmploye = new System.Windows.Forms.GroupBox();
            this.groupBoxElectricSupport = new System.Windows.Forms.GroupBox();
            this.textBoxElectricSupport = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxMade = new System.Windows.Forms.TextBox();
            this.groupBoxSimulation = new System.Windows.Forms.GroupBox();
            this.buttonMakeTrip = new System.Windows.Forms.Button();
            this.textBoxTripCounter = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBoxYear = new System.Windows.Forms.TextBox();
            this.textBoxVide2 = new System.Windows.Forms.TextBox();
            this.textBoxMonth = new System.Windows.Forms.TextBox();
            this.textBoxVide1 = new System.Windows.Forms.TextBox();
            this.textBoxDay = new System.Windows.Forms.TextBox();
            this.textBoxSerialNumber = new System.Windows.Forms.TextBox();
            this.groupBoxFuelConsumed = new System.Windows.Forms.GroupBox();
            this.textBoxFuelConsumed = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxTypeVehicule = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonSortEfficiency = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttoSearch = new System.Windows.Forms.Button();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.buttonUPDATE = new System.Windows.Forms.Button();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.buttonPrint = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.listBoxVehicule = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBoxEmploye.SuspendLayout();
            this.groupBoxElectricSupport.SuspendLayout();
            this.groupBoxSimulation.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBoxFuelConsumed.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBoxModel
            // 
            this.textBoxModel.Location = new System.Drawing.Point(224, 123);
            this.textBoxModel.Name = "textBoxModel";
            this.textBoxModel.Size = new System.Drawing.Size(109, 20);
            this.textBoxModel.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Location = new System.Drawing.Point(0, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 23);
            this.label4.TabIndex = 16;
            this.label4.Text = "Trip Counter";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.groupBox3);
            this.groupBox5.Controls.Add(this.groupBox1);
            this.groupBox5.Controls.Add(this.buttonExit);
            this.groupBox5.Controls.Add(this.buttonReset);
            this.groupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox5.Location = new System.Drawing.Point(542, 372);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(265, 103);
            this.groupBox5.TabIndex = 29;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "ANOTHER OPERATIONS";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.buttonWriteXml);
            this.groupBox3.Controls.Add(this.buttonReadXml);
            this.groupBox3.Location = new System.Drawing.Point(101, 19);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(76, 78);
            this.groupBox3.TabIndex = 26;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "FILEXML";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // buttonWriteXml
            // 
            this.buttonWriteXml.BackColor = System.Drawing.Color.Silver;
            this.buttonWriteXml.Location = new System.Drawing.Point(8, 19);
            this.buttonWriteXml.Name = "buttonWriteXml";
            this.buttonWriteXml.Size = new System.Drawing.Size(60, 24);
            this.buttonWriteXml.TabIndex = 14;
            this.buttonWriteXml.Text = "WRITE";
            this.buttonWriteXml.UseVisualStyleBackColor = false;
            this.buttonWriteXml.Click += new System.EventHandler(this.buttonWriteXml_Click);
            // 
            // buttonReadXml
            // 
            this.buttonReadXml.BackColor = System.Drawing.Color.Silver;
            this.buttonReadXml.Location = new System.Drawing.Point(8, 48);
            this.buttonReadXml.Name = "buttonReadXml";
            this.buttonReadXml.Size = new System.Drawing.Size(60, 23);
            this.buttonReadXml.TabIndex = 13;
            this.buttonReadXml.Text = "READ";
            this.buttonReadXml.UseVisualStyleBackColor = false;
            this.buttonReadXml.Click += new System.EventHandler(this.buttonReadXml_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonWriteText);
            this.groupBox1.Controls.Add(this.buttonReadText);
            this.groupBox1.Location = new System.Drawing.Point(183, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(76, 78);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "FILETEXT";
            // 
            // buttonWriteText
            // 
            this.buttonWriteText.BackColor = System.Drawing.Color.Silver;
            this.buttonWriteText.Location = new System.Drawing.Point(11, 20);
            this.buttonWriteText.Name = "buttonWriteText";
            this.buttonWriteText.Size = new System.Drawing.Size(54, 23);
            this.buttonWriteText.TabIndex = 26;
            this.buttonWriteText.Text = "WRITE";
            this.buttonWriteText.UseVisualStyleBackColor = false;
            this.buttonWriteText.Click += new System.EventHandler(this.buttonWriteText_Click);
            // 
            // buttonReadText
            // 
            this.buttonReadText.BackColor = System.Drawing.Color.Silver;
            this.buttonReadText.Location = new System.Drawing.Point(11, 48);
            this.buttonReadText.Name = "buttonReadText";
            this.buttonReadText.Size = new System.Drawing.Size(54, 23);
            this.buttonReadText.TabIndex = 25;
            this.buttonReadText.Text = "READ";
            this.buttonReadText.UseVisualStyleBackColor = false;
            this.buttonReadText.Click += new System.EventHandler(this.buttonReadText_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Red;
            this.buttonExit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonExit.Location = new System.Drawing.Point(15, 66);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(74, 23);
            this.buttonExit.TabIndex = 12;
            this.buttonExit.Text = "LOGOUT";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonReset
            // 
            this.buttonReset.BackColor = System.Drawing.Color.Silver;
            this.buttonReset.FlatAppearance.BorderColor = System.Drawing.Color.RosyBrown;
            this.buttonReset.ForeColor = System.Drawing.Color.Black;
            this.buttonReset.Location = new System.Drawing.Point(15, 31);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(74, 23);
            this.buttonReset.TabIndex = 11;
            this.buttonReset.Text = "RESET";
            this.buttonReset.UseVisualStyleBackColor = false;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // groupBoxEmploye
            // 
            this.groupBoxEmploye.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBoxEmploye.Controls.Add(this.groupBoxElectricSupport);
            this.groupBoxEmploye.Controls.Add(this.textBoxMade);
            this.groupBoxEmploye.Controls.Add(this.groupBoxSimulation);
            this.groupBoxEmploye.Controls.Add(this.groupBox7);
            this.groupBoxEmploye.Controls.Add(this.textBoxModel);
            this.groupBoxEmploye.Controls.Add(this.textBoxSerialNumber);
            this.groupBoxEmploye.Controls.Add(this.groupBoxFuelConsumed);
            this.groupBoxEmploye.Controls.Add(this.label7);
            this.groupBoxEmploye.Controls.Add(this.label3);
            this.groupBoxEmploye.Controls.Add(this.comboBoxTypeVehicule);
            this.groupBoxEmploye.Controls.Add(this.label5);
            this.groupBoxEmploye.Controls.Add(this.label2);
            this.groupBoxEmploye.Controls.Add(this.label6);
            this.groupBoxEmploye.Location = new System.Drawing.Point(26, 81);
            this.groupBoxEmploye.Name = "groupBoxEmploye";
            this.groupBoxEmploye.Size = new System.Drawing.Size(781, 269);
            this.groupBoxEmploye.TabIndex = 27;
            this.groupBoxEmploye.TabStop = false;
            // 
            // groupBoxElectricSupport
            // 
            this.groupBoxElectricSupport.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxElectricSupport.Controls.Add(this.textBoxElectricSupport);
            this.groupBoxElectricSupport.Controls.Add(this.label12);
            this.groupBoxElectricSupport.Location = new System.Drawing.Point(444, 19);
            this.groupBoxElectricSupport.Name = "groupBoxElectricSupport";
            this.groupBoxElectricSupport.Size = new System.Drawing.Size(219, 70);
            this.groupBoxElectricSupport.TabIndex = 33;
            this.groupBoxElectricSupport.TabStop = false;
            this.groupBoxElectricSupport.Text = "ElectricSupport";
            // 
            // textBoxElectricSupport
            // 
            this.textBoxElectricSupport.Location = new System.Drawing.Point(110, 28);
            this.textBoxElectricSupport.Name = "textBoxElectricSupport";
            this.textBoxElectricSupport.Size = new System.Drawing.Size(92, 20);
            this.textBoxElectricSupport.TabIndex = 28;
            // 
            // label12
            // 
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label12.Location = new System.Drawing.Point(11, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 23);
            this.label12.TabIndex = 0;
            this.label12.Text = "ElectricSupport";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxMade
            // 
            this.textBoxMade.Location = new System.Drawing.Point(224, 170);
            this.textBoxMade.Name = "textBoxMade";
            this.textBoxMade.Size = new System.Drawing.Size(109, 20);
            this.textBoxMade.TabIndex = 27;
            // 
            // groupBoxSimulation
            // 
            this.groupBoxSimulation.Controls.Add(this.buttonMakeTrip);
            this.groupBoxSimulation.Controls.Add(this.textBoxTripCounter);
            this.groupBoxSimulation.Controls.Add(this.label4);
            this.groupBoxSimulation.Location = new System.Drawing.Point(455, 170);
            this.groupBoxSimulation.Name = "groupBoxSimulation";
            this.groupBoxSimulation.Size = new System.Drawing.Size(271, 77);
            this.groupBoxSimulation.TabIndex = 33;
            this.groupBoxSimulation.TabStop = false;
            this.groupBoxSimulation.Text = "Simulation Distance";
            this.groupBoxSimulation.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // buttonMakeTrip
            // 
            this.buttonMakeTrip.BackColor = System.Drawing.Color.Green;
            this.buttonMakeTrip.Location = new System.Drawing.Point(196, 32);
            this.buttonMakeTrip.Margin = new System.Windows.Forms.Padding(2);
            this.buttonMakeTrip.Name = "buttonMakeTrip";
            this.buttonMakeTrip.Size = new System.Drawing.Size(70, 23);
            this.buttonMakeTrip.TabIndex = 25;
            this.buttonMakeTrip.Text = "Maketrip";
            this.buttonMakeTrip.UseVisualStyleBackColor = false;
            this.buttonMakeTrip.Click += new System.EventHandler(this.buttonMakeTrip_Click);
            // 
            // textBoxTripCounter
            // 
            this.textBoxTripCounter.Location = new System.Drawing.Point(97, 35);
            this.textBoxTripCounter.Name = "textBoxTripCounter";
            this.textBoxTripCounter.Size = new System.Drawing.Size(94, 20);
            this.textBoxTripCounter.TabIndex = 6;
            this.textBoxTripCounter.TextChanged += new System.EventHandler(this.textBoxTripCounter_TextChanged);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.textBoxYear);
            this.groupBox7.Controls.Add(this.textBoxVide2);
            this.groupBox7.Controls.Add(this.textBoxMonth);
            this.groupBox7.Controls.Add(this.textBoxVide1);
            this.groupBox7.Controls.Add(this.textBoxDay);
            this.groupBox7.Location = new System.Drawing.Point(224, 218);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(109, 30);
            this.groupBox7.TabIndex = 26;
            this.groupBox7.TabStop = false;
            // 
            // textBoxYear
            // 
            this.textBoxYear.Location = new System.Drawing.Point(74, 10);
            this.textBoxYear.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxYear.Name = "textBoxYear";
            this.textBoxYear.Size = new System.Drawing.Size(35, 20);
            this.textBoxYear.TabIndex = 18;
            // 
            // textBoxVide2
            // 
            this.textBoxVide2.Location = new System.Drawing.Point(58, 10);
            this.textBoxVide2.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxVide2.Name = "textBoxVide2";
            this.textBoxVide2.Size = new System.Drawing.Size(16, 20);
            this.textBoxVide2.TabIndex = 18;
            this.textBoxVide2.Text = "/";
            // 
            // textBoxMonth
            // 
            this.textBoxMonth.Location = new System.Drawing.Point(40, 10);
            this.textBoxMonth.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxMonth.Name = "textBoxMonth";
            this.textBoxMonth.Size = new System.Drawing.Size(34, 20);
            this.textBoxMonth.TabIndex = 21;
            // 
            // textBoxVide1
            // 
            this.textBoxVide1.Location = new System.Drawing.Point(29, 10);
            this.textBoxVide1.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxVide1.Name = "textBoxVide1";
            this.textBoxVide1.Size = new System.Drawing.Size(16, 20);
            this.textBoxVide1.TabIndex = 15;
            this.textBoxVide1.Text = "/";
            // 
            // textBoxDay
            // 
            this.textBoxDay.Location = new System.Drawing.Point(0, 10);
            this.textBoxDay.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxDay.Name = "textBoxDay";
            this.textBoxDay.Size = new System.Drawing.Size(36, 20);
            this.textBoxDay.TabIndex = 14;
            // 
            // textBoxSerialNumber
            // 
            this.textBoxSerialNumber.Location = new System.Drawing.Point(224, 74);
            this.textBoxSerialNumber.Name = "textBoxSerialNumber";
            this.textBoxSerialNumber.Size = new System.Drawing.Size(109, 20);
            this.textBoxSerialNumber.TabIndex = 23;
            // 
            // groupBoxFuelConsumed
            // 
            this.groupBoxFuelConsumed.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxFuelConsumed.Controls.Add(this.textBoxFuelConsumed);
            this.groupBoxFuelConsumed.Controls.Add(this.label8);
            this.groupBoxFuelConsumed.Location = new System.Drawing.Point(444, 95);
            this.groupBoxFuelConsumed.Name = "groupBoxFuelConsumed";
            this.groupBoxFuelConsumed.Size = new System.Drawing.Size(219, 70);
            this.groupBoxFuelConsumed.TabIndex = 32;
            this.groupBoxFuelConsumed.TabStop = false;
            this.groupBoxFuelConsumed.Text = "FuelConsumed  ";
            this.groupBoxFuelConsumed.Enter += new System.EventHandler(this.groupBoxFuelConsumed_Enter);
            // 
            // textBoxFuelConsumed
            // 
            this.textBoxFuelConsumed.Location = new System.Drawing.Point(113, 31);
            this.textBoxFuelConsumed.Name = "textBoxFuelConsumed";
            this.textBoxFuelConsumed.Size = new System.Drawing.Size(89, 20);
            this.textBoxFuelConsumed.TabIndex = 5;
            this.textBoxFuelConsumed.TextChanged += new System.EventHandler(this.textBoxFuelConsumed_TextChanged);
            // 
            // label8
            // 
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Location = new System.Drawing.Point(11, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 23);
            this.label8.TabIndex = 0;
            this.label8.Text = "FuelConsumed  ";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Location = new System.Drawing.Point(39, 71);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 23);
            this.label7.TabIndex = 22;
            this.label7.Text = "Serial Number";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Location = new System.Drawing.Point(39, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 23);
            this.label3.TabIndex = 15;
            this.label3.Text = "Model";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBoxTypeVehicule
            // 
            this.comboBoxTypeVehicule.FormattingEnabled = true;
            this.comboBoxTypeVehicule.Location = new System.Drawing.Point(224, 28);
            this.comboBoxTypeVehicule.Name = "comboBoxTypeVehicule";
            this.comboBoxTypeVehicule.Size = new System.Drawing.Size(109, 21);
            this.comboBoxTypeVehicule.TabIndex = 14;
            this.comboBoxTypeVehicule.SelectedIndexChanged += new System.EventHandler(this.comboBoxTypeVehicule_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Location = new System.Drawing.Point(39, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 23);
            this.label5.TabIndex = 4;
            this.label5.Text = "Type";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Location = new System.Drawing.Point(39, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 23);
            this.label2.TabIndex = 0;
            this.label2.Text = "Made";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Location = new System.Drawing.Point(39, 225);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 23);
            this.label6.TabIndex = 1;
            this.label6.Text = "Made Date";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.LightGray;
            this.groupBox2.Controls.Add(this.buttonSortEfficiency);
            this.groupBox2.Controls.Add(this.buttonClear);
            this.groupBox2.Controls.Add(this.buttoSearch);
            this.groupBox2.Controls.Add(this.buttonSearch);
            this.groupBox2.Controls.Add(this.buttonUPDATE);
            this.groupBox2.Controls.Add(this.buttonDelete);
            this.groupBox2.Controls.Add(this.buttonPrint);
            this.groupBox2.Controls.Add(this.buttonAdd);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox2.Location = new System.Drawing.Point(26, 372);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(475, 103);
            this.groupBox2.TabIndex = 28;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "GRUD OPERATIONS";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // buttonSortEfficiency
            // 
            this.buttonSortEfficiency.BackColor = System.Drawing.Color.Silver;
            this.buttonSortEfficiency.Location = new System.Drawing.Point(274, 31);
            this.buttonSortEfficiency.Name = "buttonSortEfficiency";
            this.buttonSortEfficiency.Size = new System.Drawing.Size(59, 23);
            this.buttonSortEfficiency.TabIndex = 19;
            this.buttonSortEfficiency.Text = "SORT";
            this.buttonSortEfficiency.UseVisualStyleBackColor = false;
            this.buttonSortEfficiency.Click += new System.EventHandler(this.buttonSortEfficiency_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.BackColor = System.Drawing.Color.Silver;
            this.buttonClear.Location = new System.Drawing.Point(339, 31);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(59, 23);
            this.buttonClear.TabIndex = 17;
            this.buttonClear.Text = "CLEAR";
            this.buttonClear.UseVisualStyleBackColor = false;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttoSearch
            // 
            this.buttoSearch.BackColor = System.Drawing.Color.Silver;
            this.buttoSearch.Location = new System.Drawing.Point(404, 31);
            this.buttoSearch.Name = "buttoSearch";
            this.buttoSearch.Size = new System.Drawing.Size(62, 23);
            this.buttoSearch.TabIndex = 16;
            this.buttoSearch.Text = "SEARCH";
            this.buttoSearch.UseVisualStyleBackColor = false;
            this.buttoSearch.Click += new System.EventHandler(this.buttoSearch_Click);
            // 
            // buttonSearch
            // 
            this.buttonSearch.BackColor = System.Drawing.Color.Silver;
            this.buttonSearch.Location = new System.Drawing.Point(12, 161);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(75, 23);
            this.buttonSearch.TabIndex = 15;
            this.buttonSearch.Text = "SEARCH";
            this.buttonSearch.UseVisualStyleBackColor = false;
            // 
            // buttonUPDATE
            // 
            this.buttonUPDATE.BackColor = System.Drawing.Color.Silver;
            this.buttonUPDATE.Location = new System.Drawing.Point(210, 31);
            this.buttonUPDATE.Name = "buttonUPDATE";
            this.buttonUPDATE.Size = new System.Drawing.Size(60, 23);
            this.buttonUPDATE.TabIndex = 14;
            this.buttonUPDATE.Text = "UPDATE";
            this.buttonUPDATE.UseVisualStyleBackColor = false;
            this.buttonUPDATE.Click += new System.EventHandler(this.buttonUPDATE_Click);
            // 
            // buttonDelete
            // 
            this.buttonDelete.BackColor = System.Drawing.Color.Silver;
            this.buttonDelete.Location = new System.Drawing.Point(139, 31);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(65, 23);
            this.buttonDelete.TabIndex = 13;
            this.buttonDelete.Text = "DELETE";
            this.buttonDelete.UseVisualStyleBackColor = false;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // buttonPrint
            // 
            this.buttonPrint.BackColor = System.Drawing.Color.Silver;
            this.buttonPrint.Location = new System.Drawing.Point(71, 31);
            this.buttonPrint.Name = "buttonPrint";
            this.buttonPrint.Size = new System.Drawing.Size(62, 23);
            this.buttonPrint.TabIndex = 12;
            this.buttonPrint.Text = "PRINT";
            this.buttonPrint.UseVisualStyleBackColor = false;
            this.buttonPrint.Click += new System.EventHandler(this.buttonPrint_Click);
            // 
            // buttonAdd
            // 
            this.buttonAdd.BackColor = System.Drawing.Color.Silver;
            this.buttonAdd.FlatAppearance.BorderColor = System.Drawing.Color.RosyBrown;
            this.buttonAdd.ForeColor = System.Drawing.Color.Black;
            this.buttonAdd.Location = new System.Drawing.Point(6, 31);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(59, 23);
            this.buttonAdd.TabIndex = 11;
            this.buttonAdd.Text = "ADD";
            this.buttonAdd.UseVisualStyleBackColor = false;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // listBoxVehicule
            // 
            this.listBoxVehicule.FormattingEnabled = true;
            this.listBoxVehicule.Location = new System.Drawing.Point(26, 481);
            this.listBoxVehicule.Name = "listBoxVehicule";
            this.listBoxVehicule.Size = new System.Drawing.Size(781, 212);
            this.listBoxVehicule.TabIndex = 31;
            this.listBoxVehicule.SelectedIndexChanged += new System.EventHandler(this.listBoxVehicule_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(272, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(301, 47);
            this.label1.TabIndex = 26;
            this.label1.Text = "VEHICULE FACTORY";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormVehicule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(846, 743);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBoxEmploye);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBoxVehicule);
            this.Name = "FormVehicule";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vehicule";
            this.Load += new System.EventHandler(this.Vehicule_Load);
            this.groupBox5.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBoxEmploye.ResumeLayout(false);
            this.groupBoxEmploye.PerformLayout();
            this.groupBoxElectricSupport.ResumeLayout(false);
            this.groupBoxElectricSupport.PerformLayout();
            this.groupBoxSimulation.ResumeLayout(false);
            this.groupBoxSimulation.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBoxFuelConsumed.ResumeLayout(false);
            this.groupBoxFuelConsumed.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxModel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button buttonWriteXml;
        private System.Windows.Forms.Button buttonReadXml;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonWriteText;
        private System.Windows.Forms.Button buttonReadText;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.GroupBox groupBoxEmploye;
        private System.Windows.Forms.TextBox textBoxSerialNumber;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBoxTypeVehicule;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBoxFuelConsumed;
        private System.Windows.Forms.TextBox textBoxFuelConsumed;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBoxSimulation;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttoSearch;
        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.Button buttonUPDATE;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.Button buttonPrint;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.ListBox listBoxVehicule;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBoxYear;
        private System.Windows.Forms.TextBox textBoxVide2;
        private System.Windows.Forms.TextBox textBoxMonth;
        private System.Windows.Forms.TextBox textBoxVide1;
        private System.Windows.Forms.TextBox textBoxDay;
        private System.Windows.Forms.GroupBox groupBoxElectricSupport;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxMade;
        private System.Windows.Forms.TextBox textBoxElectricSupport;
        private System.Windows.Forms.TextBox textBoxTripCounter;
        private System.Windows.Forms.Button buttonSortEfficiency;
        private System.Windows.Forms.Button buttonMakeTrip;
        private System.Windows.Forms.Label label1;
    }
}

