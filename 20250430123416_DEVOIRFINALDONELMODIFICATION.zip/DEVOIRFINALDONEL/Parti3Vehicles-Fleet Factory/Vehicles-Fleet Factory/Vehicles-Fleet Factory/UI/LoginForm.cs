﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vehicles_Fleet_Factory.UI
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            // Récupérer les informations entrées par l'utilisateur
            string username = this.textBoxUsername.Text.Trim().ToLower();
            string password = this.textBoxPassWord.Text.Trim().ToLower();

            // Vérifier les informations d'identification (par exemple, "admin" pour le nom d'utilisateur et "1234" pour le mot de passe)
            if (username == "admin" && password == "123")
            {
                // Affiche un message de bienvenue à l'utilisateur
                MessageBox.Show("Connexion réussie. Bienvenue " + username + " !");

                // Ouvre le formulaire FormVehicule si les identifiants sont corrects
                FormVehicule formVehicule = new FormVehicule();
                formVehicule.Show();
                this.Hide(); // Cache le formulaire de connexion
            }
            else
            {
                // Affiche un message d'erreur si les identifiants sont incorrects
                MessageBox.Show("Nom d'utilisateur ou mot de passe incorrect. Veuillez réessayer.");

                // Efface les TextBox pour que l'utilisateur puisse entrer à nouveau les informations
                this.textBoxUsername.Clear();
                this.textBoxPassWord.Clear();

                // Redonne le focus à la TextBox du nom d'utilisateur
                this.textBoxUsername.Focus();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
