﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles_Fleet_Factory.BLL
{
    // "Classe personnalisée pour représenter une date"
    public class Date
    {
        private int day;   // "Jour"
        private int month;  // "Mois"
        private int year;   // "Année"
        private string v;

        // "Constructeur par defaut" 
        public Date()
        {
            this.day = 0;
            this.month = 0;
            this.year = 0;
        }

        // "Constructeur permettant d'initialiser une date"
        public Date(int day, int month, int year)
        {
            this.day = day;
            this.month = month;
            this.year = year;
        }

        public Date(string v)
        {
            this.v = v;
        }

        // "Methodes Getters et setters pour accéder/modifier les attributs"
        public int getDay() { return this.day; }
        public void setDay(int day) { this.day = day; }

        public int getMonth() { return this.month; }
        public void setMonth(int month) { this.month = month; }

        public int getYear() { return this.year; }
        public void setYear(int year) { this.year = year; }


        //public Properties Get/Set
        //syntax de C++

        //public property Year
        public int Year
        {
            get { return this.year; }
            set { this.year = value; }
        }

        //public property Month
        public int Month
        {
            get { return this.month; }
            set { this.month = value; }
        }

        //public property Day
        public int Day
        {
            get { return this.day; }
            set { this.day = value; }
        }

        // "Méthode pour obtenir la date au format lisible (ex. : 23/04/2025)"

        public override string ToString()
        {
            return day + "/" + month + "/" + year;
        }

        // Méthode pour obtenir les informations sur la durée
        public string GetDateInfo()
        {
            return day + "/" + month + "/" + year;
        }
    }

}
