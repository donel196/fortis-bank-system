﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles_Fleet_Factory.BLL
{
    public class DataCollection
    { 
        // Liste globale regroupant tous les véhicules (base)
        public static List<Vehicule> listOfVehicules = new List<Vehicule>();
        public static List<Vehicule> ListOfVehicules
        {
            get { return listOfVehicules; }
            set { listOfVehicules = value; }
        }

        // Liste regroupant uniquement les véhicules électriques
        private static List<ElectricVehicule> listOfElectricVehicules = new List<ElectricVehicule>();
        public static List<ElectricVehicule> ListOfElectricVehicules
        {
            get { return listOfElectricVehicules; }
            set { listOfElectricVehicules = value; }
        }

        // Liste regroupant uniquement les véhicules à essence
        private static List<GazolineVehicule> listOfGazolineVehicules = new List<GazolineVehicule>();
        public static List<GazolineVehicule> ListOfGazolineVehicules
        {
            get { return listOfGazolineVehicules; }
            set { listOfGazolineVehicules = value; }
        }

        // Liste regroupant uniquement les véhicules hybrides
        private static List<HybridVehicule> listOfHybridVehicules = new List<HybridVehicule>();
        public static List<HybridVehicule> ListOfHybridVehicules
        {
            get { return listOfHybridVehicules; }
            set { listOfHybridVehicules = value; }
        }

        // Liste regroupant uniquement les véhicules sportifs
        private static List<SportVehicule> listOfSportVehicules = new List<SportVehicule>();
        public static List<SportVehicule> ListOfSportVehicules
        {
            get { return listOfSportVehicules; }
            set { listOfSportVehicules = value; }
        }

        
        // Retourne le nombre total de véhicules dans la flotte.   
        public static int Count()
        {
            return ListOfVehicules.Count;
        }

        // Ajoute un nouveau véhicule à la liste.
        public static void Add(Vehicule newItem)
        {
            ListOfVehicules.Add(newItem);
        }

        
        // Supprime le véhicule spécifié de la liste.
        public static void Remove(Vehicule newItem)
        {
            ListOfVehicules.Remove(newItem);
        }

        // Supprime le véhicule se trouvant à l'indice indiqué.

        public static void RemoveAt(int currentIndex)
        {
            ListOfVehicules.RemoveAt(currentIndex);
        }

       
        // Insère un véhicule à l'indice spécifié.
    
        public static void InsertAt(int currentIndex, Vehicule currentItem)
        {
            listOfVehicules.Insert(currentIndex, currentItem);
        }

        
        // Efface tous les véhicules de la liste.
     
        public static void Clear()
        {
            listOfVehicules.Clear();
        }

      
        /// Recherche un véhicule dont le numéro de série correspond à la clé donnée.
        // Le numéro de série recherché.
        // Le véhicule trouvé ou null si aucun n'est trouvé.
        public static Vehicule Search(string key)
        {
            Vehicule searchedVehicle = null;
            foreach (Vehicule currentElement in ListOfVehicules)
            {
                if (currentElement.SerialNumber == key)
                {
                    searchedVehicle = currentElement;
                    break;
                }
            }
            return searchedVehicle;
        }

        
        /// Met à jour le véhicule situé à l'indice spécifié par l'objet mis à jour.
       
        public static void Update(int index, Vehicule updatedItem)
        {
            if (index >= 0 && index < ListOfVehicules.Count)
                ListOfVehicules[index] = updatedItem;
        }

      
        // Retourne la liste des véhicules de type ElectricVehicule.
      
        public static List<ElectricVehicule> GetListOfElectric()
        {
            List<ElectricVehicule> listOfElectricVehicles = new List<ElectricVehicule>();

            foreach (Vehicule currentVehicle in ListOfVehicules)
            {
                if (currentVehicle is ElectricVehicule)
                {
                    listOfElectricVehicles.Add((ElectricVehicule)currentVehicle);
                }
            }
            return listOfElectricVehicles;
        }


        // Retourne la liste des véhicules de type GazolineVehicule.
        public static List<GazolineVehicule> GetListOfGasoline()
        {
            List<GazolineVehicule> listOfGasolineVehicles = new List<GazolineVehicule>();

            foreach (Vehicule currentVehicle in ListOfVehicules)
            {
                if (currentVehicle is GazolineVehicule)
                {
                    listOfGasolineVehicles.Add((GazolineVehicule)currentVehicle);
                }
            }
            return listOfGasolineVehicles;
        }

        // Retourne la liste des véhicules de type HybridVehicule.
        public static List<HybridVehicule> GetListOfHybrid()
        {
            List<HybridVehicule> listOfHybridVehicles = new List<HybridVehicule>();

            foreach (Vehicule currentVehicle in ListOfVehicules)
            {
                if (currentVehicle is HybridVehicule)
                {
                    listOfHybridVehicles.Add((HybridVehicule)currentVehicle);
                }
            }
            return listOfHybridVehicles;
        }

       
        // Retourne la liste des véhicules de type SportVehicule.
        public static List<SportVehicule> GetListOfSport()
        {
            List<SportVehicule> listOfSportVehicles = new List<SportVehicule>();

            foreach (Vehicule currentVehicle in ListOfVehicules)
            {
                if (currentVehicle is SportVehicule)
                {
                    listOfSportVehicles.Add((SportVehicule)currentVehicle);
                }
            }
            return listOfSportVehicles;
        }
    }
}
