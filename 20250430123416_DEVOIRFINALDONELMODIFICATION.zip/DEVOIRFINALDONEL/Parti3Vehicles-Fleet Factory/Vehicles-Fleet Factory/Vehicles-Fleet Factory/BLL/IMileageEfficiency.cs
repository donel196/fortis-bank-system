﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles_Fleet_Factory.BLL
{
    public interface IMileageEfficiency
    {
        double CalculateMileageEfficiency();
    }
}
