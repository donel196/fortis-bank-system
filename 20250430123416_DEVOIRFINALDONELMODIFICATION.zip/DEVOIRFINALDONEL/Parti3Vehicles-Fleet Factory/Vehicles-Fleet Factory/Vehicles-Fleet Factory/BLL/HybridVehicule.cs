﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Vehicles_Fleet_Factory.BLL
{
    [XmlInclude(typeof(ElectricVehicule))]
    [XmlInclude(typeof(GazolineVehicule))]
    [XmlInclude(typeof(SportVehicule))]
    [XmlInclude(typeof(HybridVehicule))]
    // CLASSE DERIVEE : HybridVehicule
    // Représente un véhicule hybride combinant consommation d'essence et d'électricité.
    public class HybridVehicule : Vehicule
    {
        private double fuelConsumption;         // Consommation de carburant (litres/km)
        private double electricConsumption;     // Consommation électrique (kWh/km)


        public HybridVehicule()
           : base()
        {
            this.fuelConsumption = 0;
            this.electricConsumption = 0;
        }

        public HybridVehicule(string serialNumber, string made, string model, Date madeDate, double fuelConsumption, double electricConsumption, EnumTypeVehicule typeVehicule)
            : base(serialNumber, made, model, madeDate,typeVehicule)
        {
            this.fuelConsumption = fuelConsumption;
            this.electricConsumption = electricConsumption;
        }


        // GETTERS ET SETTERS (Syntaxe Java)
        // --------------------------
        public void setElectricConsumption(double electricConsumption) { this.electricConsumption = electricConsumption; }
        public double getElectricConsumption() { return this.electricConsumption; }

        public void setFuelConsumption(double fuelConsumption) { this.fuelConsumption = fuelConsumption; }
        public double getFuelConsumption() { return this.fuelConsumption; }

        // --------------------------
        // GETTERS ET SETTERS (Syntaxe C#)
        // --------------------------
        public double ElectricConsumption
        {
            get { return this.electricConsumption; }
            set { this.electricConsumption = value; }
        }

        public double FuelConsumption
        {
            get { return this.fuelConsumption; }
            set { this.fuelConsumption = value; }
        }
        // Calcul de l'efficacité globale en combinant les deux consommations.
        public override double CalculateMileageEfficiency()
        {
            double totalConsumption = fuelConsumption + electricConsumption;
            if (tripCounter > 0)
            {
                return tripCounter / totalConsumption;
            }
            else
            {
                return 0;
            }
        }

        public override string ToString()
        {
            return base.ToString() +
                   ", Fuel Consumption: " + fuelConsumption.ToString("F2") + " L/km" +
                   ", Electric Consumption: " + electricConsumption.ToString("F2") + " kWh";
        }

        public override string AfficherInformations()
        {
            return base.AfficherInformations() +
                   ", Fuel Consumption: " + fuelConsumption.ToString("F2") + " L/km" +
                   ", Electric Consumption: " + electricConsumption.ToString("F2") + " kWh";
        }
    }
}
