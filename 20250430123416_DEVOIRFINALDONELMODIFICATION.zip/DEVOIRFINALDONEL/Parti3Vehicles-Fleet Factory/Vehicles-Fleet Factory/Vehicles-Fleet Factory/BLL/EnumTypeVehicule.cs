﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vehicles_Fleet_Factory.BLL
{
    public enum EnumTypeVehicule
    {
        GazolineVehicule,
        ElectricVehicule,
        HybridVehicule,
        SportVehicule,
        Undefined
    }
}