﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Vehicles_Fleet_Factory.BLL
{
    [XmlInclude(typeof(ElectricVehicule))]
    [XmlInclude(typeof(GazolineVehicule))]
    [XmlInclude(typeof(SportVehicule))]
    [XmlInclude(typeof(HybridVehicule))]
    // "Classe héritière : Véhicule sportif (utilise à la fois électricité et essence)"
    public class SportVehicule : Vehicule
    {
        private double electricConsumption; // "Consommation électrique (kWh par km)"
        private double fuelConsumption;     // "Consommation de carburant (litres par km)"

        public SportVehicule()
           : base()
        {
            this.fuelConsumption = 0;
            this.electricConsumption = 0;
        }

        public SportVehicule(string serialNumber, string made, string model, Date madeDate, double fuelConsumption, double electricConsumption,EnumTypeVehicule typeVehicule)
            : base(serialNumber, made, model, madeDate, typeVehicule)
        {
            this.fuelConsumption = fuelConsumption;
            this.electricConsumption = electricConsumption;
        }


        // GETTERS ET SETTERS (Syntaxe Java)
        // --------------------------
        public void setElectricConsumption(double electricConsumption) { this.electricConsumption = electricConsumption; }
        public double getElectricConsumption() { return this.electricConsumption; }

        public void setFuelConsumption(double fuelConsumption) { this.fuelConsumption = fuelConsumption; }
        public double getFuelConsumption() { return this.fuelConsumption; }

        // --------------------------
        // GETTERS ET SETTERS (Syntaxe C#)
        // --------------------------
        public double ElectricConsumption
        {
            get { return this.electricConsumption; }
            set { this.electricConsumption = value; }
        }

        public double FuelConsumption
        {
            get { return this.fuelConsumption; }
            set { this.fuelConsumption = value; }
        }

        // Calcul de l'efficacité globale en combinant les deux consommations.
        public override double CalculateMileageEfficiency()
        {
            double totalConsumption = fuelConsumption + electricConsumption;
            if (tripCounter > 0)
            {
                return tripCounter / totalConsumption;
            }
            else
            {
                return 0;
            }
        }

        // "Méthode ToString() pour représenter les informations complètes d'un véhicule sportif"
        public override string ToString()
        {
            return base.ToString() + ", Electric Consumption: " + electricConsumption +", Fuel Consumption: " + fuelConsumption ;
        }

        public override string AfficherInformations()
        {
            return base.AfficherInformations() + ", Fuel Consumption: " + fuelConsumption + ", Electric Consumption: " + electricConsumption;

        }
    }

}
