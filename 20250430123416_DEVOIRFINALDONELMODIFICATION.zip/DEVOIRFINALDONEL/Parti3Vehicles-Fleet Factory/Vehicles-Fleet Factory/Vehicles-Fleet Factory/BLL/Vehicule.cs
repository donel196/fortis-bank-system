﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Vehicles_Fleet_Factory.BLL
{

    [XmlInclude(typeof(ElectricVehicule))]
    [XmlInclude(typeof(GazolineVehicule))]
    [XmlInclude(typeof(SportVehicule))]
    [XmlInclude(typeof(HybridVehicule))]
    public abstract class Vehicule : IMileageEfficiency
    {
        // "Attributs privés représentant les informations principales du véhicule"
        private string serialNumber;           // "Numéro de série unique"
        private string made;                   // "Fabricant du véhicule"
        private string model;                  // "Modèle du véhicule"
        private Date madeDate;                 // "Date de fabrication (utilisant la classe personnalisée Date)"
        private EnumTypeVehicule typeVehicule; // "Type du véhicule issu de l'énumération EnumTypeVehicule"

        // "Variable protégée pour enregistrer la distance totale parcourue"
        protected double tripCounter;


           public Vehicule()
           {
            this.serialNumber = string.Empty;         // "Numéro de série par défaut"
            this.made = string.Empty;                   // "Fabricant par défaut"
            this.model = string.Empty;                  // "Modèle par défaut"
            this.madeDate = new Date();                 // "Date de fabrication par défaut"
            this.tripCounter = 0.0;                       // "Initialisation du compteur de trajets à zéro"
            this.typeVehicule = EnumTypeVehicule.Undefined;  // "Type par défaut"
            
           }

        // --------------------------
        // CONSTRUCTEUR PAR PARAMÈTRES
        // --------------------------
        // "Ce constructeur initialise les informations nécessaires pour un véhicule"
        public Vehicule(string serialNumber, string made, string model, Date madeDate, EnumTypeVehicule typeVehicule)
        {
            this.tripCounter = 0;                 // "Initialisation du compteur de trajets à zéro"
            this.serialNumber = serialNumber;     // "Numéro de série du véhicule"
            this.made = made;                     // "Nom du fabricant du véhicule"
            this.model = model;                   // "Modèle spécifique du véhicule"
            this.madeDate = madeDate;             // "Date de fabrication (utilise la classe Date)"
            this.typeVehicule = typeVehicule;     // "Type du véhicule défini par l'énumération"
        }


        // --------------------------
        // METHODES GETTERS ET SETTERS (Syntaxe Java)
        // --------------------------
        public void setSerialNumber(string serialNumber) { this.serialNumber = serialNumber; }
        public string getSerialNumber() { return this.serialNumber; }

        public void setMade(string made) { this.made = made; }
        public string getMade() { return this.made; }

        public void setModel(string model) { this.model = model; }
        public string getModel() { return this.model; }

        public void setMadeDate(Date madeDate) { this.madeDate = madeDate; }
        public Date getMadeDate() { return this.madeDate; }

        public void setTripCounter(double tripCounter) { this.tripCounter = tripCounter; }
        public double getTripCounter() { return this.tripCounter; }

        public void setTypeVehicule(EnumTypeVehicule typeVehicule) { this.typeVehicule = typeVehicule; }
        public EnumTypeVehicule getTypeVehicule() { return this.typeVehicule; }

        // --------------------------
        // PROPRIETES GETTERS ET SETTERS (Syntaxe C#)
        // --------------------------
        public string SerialNumber
        {
            get { return this.serialNumber; }
            set { this.serialNumber = value; }
        }

        public string Made
        {
            get { return this.made; }
            set { this.made = value; }
        }

        public string Model
        {
            get { return this.model; }
            set { this.model = value; }
        }

        public Date MadeDate
        {
            get { return this.madeDate; }
            set { this.madeDate = value; }
        }

        public double TripCounter
        {
            get { return this.tripCounter; }
            set { this.tripCounter = value; } // "Accessible uniquement dans les sous-classes"
        }

        public EnumTypeVehicule TypeVehicule
        {
            get { return this.typeVehicule; }
            set { this.typeVehicule = value; }
        }

        // --------------------------
        // CONSTRUCTEUR PAR DÉFAUT
        // --------------------------
     
        // --------------------------
        // MÉTHODES POUR ENREGISTRER DES TRAJETS
        // --------------------------
        // "Méthode sans paramètre qui ajoute un trajet de base"

        public void MakeTrip()
        {
            tripCounter += 1; // "Incrémente le compteur de trajets de 1"
        }

        // "Méthode pour ajouter un trajet avec une distance spécifique"
        public void MakeTrip(double distance)
        {
            if (distance > 0)
            {
                tripCounter += distance; // "Ajoute la distance au compteur si elle est valide (> 0)"
            }
        }

        // --------------------------
        // MÉTHODE ABSTRAITE
        // --------------------------
        // "Méthode imposée aux sous-classes pour calculer l'efficacité énergétique"
        public abstract double CalculateMileageEfficiency();

        // --------------------------
        // MÉTHODE ToString()
        // --------------------------
        // "Fournit une représentation textuelle explicite du véhicule"
        public override string ToString()
        {
            return "SN: " + serialNumber +
                   ", Made: " + made +
                   ", Model: " + model +
                   ", Date: " + madeDate +
                   ", Trips: " + tripCounter +
                   ", Type: " + typeVehicule;
        }

        // --------------------------
        // MÉTHODE AfficherInformations()
        // --------------------------
        // "Fournit une représentation textuelle explicite du véhicule"
        public virtual string AfficherInformations()
        {
            return "SN: " + serialNumber +
                   ", Made: " + made +
                   ", Model: " + model +
                   ", Date: " + madeDate +
                   ", Trips: " + tripCounter +
                   ", Type: " + typeVehicule;
        }


    }

}
