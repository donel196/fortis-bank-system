﻿using System.Xml.Serialization;

namespace Vehicles_Fleet_Factory.BLL
{
    // Classe héritière : Véhicule à essence
    [XmlInclude(typeof(GazolineVehicule))] 
    [XmlInclude(typeof(ElectricVehicule))]
    [XmlInclude(typeof(HybridVehicule))]
    [XmlInclude(typeof(SportVehicule))]
    public class GazolineVehicule : Vehicule
    {
        private double fuelConsumption; // consommation de carburant (litres par km)

        public GazolineVehicule()
            : base()
        {
            this.fuelConsumption = 0;
        }

        public GazolineVehicule(string serialNumber, string made, string model, Date madeDate, double fuelConsumption,EnumTypeVehicule typeVehicule)
            : base(serialNumber, made, model, madeDate,typeVehicule)
        {
            this.fuelConsumption = fuelConsumption;
        }


        // METHODES GETTERS ET SETTERS (Syntaxe Java)
        // --------------------------
        public void setGazolineVehicule(double fuelConsumption) { this.fuelConsumption = fuelConsumption; }
        public double getGazolineVehicule() { return this.fuelConsumption; }


        // --------------------------
        // PROPRIETES GETTERS ET SETTERS (Syntaxe C#)
        // --------------------------
        public double FuelConsumption
        {
            get { return this.fuelConsumption; }
            set { this.fuelConsumption = value; }
        }


        public override double CalculateMileageEfficiency()
        {
            if (tripCounter > 0)
            {
                return tripCounter / fuelConsumption;
            }
            else
            {
                return 0;
            };
        }

        public override string ToString()
        {
            return base.ToString() + ", Fuel Consumption: " + fuelConsumption.ToString("F2") + " L/km";
        }

        public override string AfficherInformations()
        {
            return base.AfficherInformations() + ", Fuel Consumption: " + fuelConsumption.ToString("F2") + " L/km";
        }

    }
}
