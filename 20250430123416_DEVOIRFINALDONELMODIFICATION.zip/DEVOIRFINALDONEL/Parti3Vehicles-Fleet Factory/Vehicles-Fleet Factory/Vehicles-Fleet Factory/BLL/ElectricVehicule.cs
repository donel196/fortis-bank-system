﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Vehicles_Fleet_Factory.BLL
{
    [XmlInclude(typeof(ElectricVehicule))]
    [XmlInclude(typeof(GazolineVehicule))]
    [XmlInclude(typeof(SportVehicule))]
    [XmlInclude(typeof(HybridVehicule))]
    // Classe héritière : Véhicule électrique
    public class ElectricVehicule : Vehicule
    {

        private double electricConsumption; // consommation électrique (kWh par km)


        public ElectricVehicule()
           : base()
        {
            this.electricConsumption = 0;
        }

        // Constructeur pour initialiser un véhicule électrique
        public ElectricVehicule(string serialNumber, string made, string model, Date madeDate, double electricConsumption, EnumTypeVehicule typeVehicule)
            : base(serialNumber, made, model, madeDate, typeVehicule)
        {
            this.electricConsumption = electricConsumption;
        }

        // METHODES GETTERS ET SETTERS (Syntaxe Java)
        // --------------------------
        public void setElectricConsumption(double electricConsumption) { this.electricConsumption = electricConsumption; }
        public double getElectricConsumption() { return this.electricConsumption; }


        // --------------------------
        // PROPRIETES GETTERS ET SETTERS (Syntaxe C#)
        // --------------------------
        public double ElectricConsumption
        {
            get { return this.electricConsumption; }
            set { this.electricConsumption = value; }
        }

        // Implémentation du calcul de l'efficacité énergétique pour les véhicules électriques
        public override double CalculateMileageEfficiency()
        {
            if (tripCounter > 0)
            {
                // "Calcule l'efficacité énergétique en utilisant les consommations combinées"
                return tripCounter / (electricConsumption);
            }
            else
            {
                // "Retourne 0 si aucun trajet n'a été effectué"
                return 0;
            }
        }

        // Représentation textuelle complète de l'objet
        public override string ToString()
        {
            return base.ToString() + ", Electric Consumption: " + electricConsumption.ToString("F2") + " kWh";
        }

        public override string AfficherInformations()
        {
            return base.AfficherInformations() + ", Electric Consumption: " + electricConsumption.ToString("F2") + " kWh";
        }


    }
}
