﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;
using System.Reflection;
using System.Xml.Linq;

namespace Vehicles_Fleet_Factory.BLL
{
    public static class VehiculeFileManager
    {


        // Chemin relatif vers le fichier XML dans lequel seront stockées les données des véhicules
        private static string xmlFilePath = "../../DAL/fleet.xml";
        // Chemin relatif vers le fichier texte dans lequel sera écrite la représentation textuelle des véhicules
        private static string textFilePath = "../../DAL/fleet.txt";

        // ----------- GESTION DES FICHIERS TEXTE -----------

        public static void WriteToTextFile(List<Vehicule> listOfItems)
        {
            using (StreamWriter writer = new StreamWriter(textFilePath))
            {
                foreach (Vehicule veh in listOfItems)
                {
                    writer.WriteLine(veh.ToString());
                }
            }
        }



        public static List<string> ReadFromTextFile()
        {
            List<string> vehiculesLine = new List<string>();

            if (!File.Exists(textFilePath))
            {
                return vehiculesLine;
            }

            using (StreamReader reader = new StreamReader(textFilePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    vehiculesLine.Add(line);
                }
            }

            return vehiculesLine;
        }


        public static void WriteToXmlFile(List<Vehicule> listOfItems)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Vehicule>));

            using (FileStream fs = new FileStream(xmlFilePath, FileMode.Create))
            {
                serializer.Serialize(fs, listOfItems);
            }
        }




        public static List<Vehicule> ReadFromXmlFile()
        {
            if (!File.Exists(xmlFilePath))
                return new List<Vehicule>();

            XmlSerializer serializer = new XmlSerializer(typeof(List<Vehicule>));

            using (FileStream fs = new FileStream(xmlFilePath, FileMode.Open))
            {
                return (List<Vehicule>)serializer.Deserialize(fs);
            }
        }


    }
}
